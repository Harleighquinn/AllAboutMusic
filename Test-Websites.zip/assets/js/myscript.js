var i = 4
var j = 9

alert("welcome to my website")

var sum = function(a,b) {
    return a+b;
} ;
for (var i = 1; i <= 4 i++) {
    console.log(sum i,1)
}